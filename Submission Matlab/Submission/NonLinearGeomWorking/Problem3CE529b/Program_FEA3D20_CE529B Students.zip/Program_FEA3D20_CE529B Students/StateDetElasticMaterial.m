function [Et,tijel,Mtijel]=StateDetElasticMaterial(young,poisson,alfa,FlagNLG)
% Et     : Material Matrix 6x6
% tijel  : vector with the 6 stresses for the gauss point analyzed
% Mtijel : 3x3 Matrix stress for the gauss point analyzed

    %Create the Elastic Matrix for the 
    Et=zeros(6,6);
end
